public class FirstJavaProgram 
{

	public static void main(String args[])
	{
	
		System.out.println("Hello world..welcome to java training...");
		System.out.println("Selenium training....");
	}

	
	
}
