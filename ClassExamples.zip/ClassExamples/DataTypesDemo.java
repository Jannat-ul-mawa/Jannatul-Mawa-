
public class DataTypesDemo {

	public static void main(String[] args) {
	
		int a=100; //int type of data
		double d=15.5;
		char c='A';
		boolean b=false;
		
		String s="welcome";

		System.out.println(a);
		System.out.println(d);
		System.out.println(c);
		System.out.println(b);
		System.out.println(s);
	}

}
